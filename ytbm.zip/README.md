# youtube-block-music
Block music videos from YouTube
